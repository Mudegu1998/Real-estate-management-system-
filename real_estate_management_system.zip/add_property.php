<?php include('db.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/styles.css">
    <title>Add Property</title>
</head>
<body>
    <h1>Add New Property</h1>
    <form action="add_property.php" method="POST" enctype="multipart/form-data">
        <input type="text" name="title" placeholder="Title" required>
        <textarea name="description" placeholder="Description" required></textarea>
        <input type="number" name="price" placeholder="Price" required>
        <input type="text" name="location" placeholder="Location" required>
        <input type="file" name="image" required>
        <button type="submit" name="submit">Add Property</button>
    </form>
    <?php
    if (isset($_POST['submit'])) {
        $title = $_POST['title'];
        $description = $_POST['description'];
        $price = $_POST['price'];
        $location = $_POST['location'];
        $image = $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], "images/$image");
        
        $conn->query("INSERT INTO properties (title, description, price, location, image) 
                      VALUES ('$title', '$description', '$price', '$location', '$image')");
        echo "Property added successfully!";
    }
    ?>
</body>
</html>
