<?php include('db.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <title>Real Estate Management</title>
</head>
<body>
    <h1>Available Properties</h1>
    <div class="property-list">
        <?php
        $result = $conn->query("SELECT * FROM properties");
        while ($row = $result->fetch_assoc()) {
            echo "<div class='property'>
                    <img src='images/{$row['image']}' alt='{$row['title']}'>
                    <h2>{$row['title']}</h2>
                    <p>{$row['description']}</p>
                    <p>Price: {$row['price']} USD</p>
                    <p>Location: {$row['location']}</p>
                  </div>";
        }
        ?>
    </div>
</body>
</html>
