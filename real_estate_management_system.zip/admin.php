<?php include('db.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/styles.css">
    <title>Admin Panel</title>
</head>
<body>
    <h1>Admin Panel</h1>
    <a href="add_property.php">Add New Property</a>
    <h2>Property List</h2>
    <div class="property-list">
        <?php
        $result = $conn->query("SELECT * FROM properties");
        while ($row = $result->fetch_assoc()) {
            echo "<div class='property'>
                    <h2>{$row['title']}</h2>
                    <p>{$row['description']}</p>
                    <a href='delete_property.php?id={$row['id']}'>Delete</a>
                  </div>";
        }
        ?>
    </div>
</body>
</html>
